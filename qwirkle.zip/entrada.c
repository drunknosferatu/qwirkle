#include <stdio.h>
#include <stdlib.h>

#include "struct.h"

//recebe as configurações do jogo, por meio da struct config
config entrada(config dados) {

}

//inicializa as peças do jogo
void inicializaPecas(*pecas[3]) {
	
	//aloca memória para as peças 
	for(int i = 0; i < 107; i++) {
		pecas[i] = (char *) malloc(sizeof(char)*3)
	}
	
	//inicializa as peças de fato
	int aux1 = 'A';	
	int aux2 = '1';
	for(int i = 0; i < 107; i++) {
		pecas[i][0] = aux1;
		pecas[i][1] = aux2;
		pecas[i][2] = '\0';
		aux1++;
		aux2++;
		if (aux1 == 'F') {
			aux1 = 'A';
			aux2 = '1';
		}
	}
}
