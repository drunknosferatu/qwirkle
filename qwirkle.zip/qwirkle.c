#include <stdio.h>
#include <stdlib.h>

#include "struct.h"
#include "entrada.h"
#include "alocacao.h"

void main() {
	config dados;
	char *pecas[3];
	inicializaPecas(pecas);
}
