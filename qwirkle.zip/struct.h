//struct que armazena as configurações do jogo
typedef struct {
	char **jog;
} config;
